import React from "react";

export default function ShowMarks()
{
    return(
        <div>
            <h3>TakeExam</h3>
        </div>
    )
}
