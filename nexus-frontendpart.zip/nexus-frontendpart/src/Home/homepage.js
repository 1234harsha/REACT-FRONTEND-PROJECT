import React from 'react';
import { NavLink } from 'react-router-dom';

import "./css/linearicons.css";
import "./css/font-awesome.min.css";
import "./css/bootstrap.css";
import "./css/magnific-popup.css";
import "./css/nice-select.css";							
import "./css/animate.min.css";
import "./css/owl.carousel.css";			
import "./css/jquery-ui.css";			
import "./css/main.css";
const Home=()=>{
    return(
        <>
 {/* header section */}
<header id="header" >
    <div id="home">
	  		<div class="header-top">
	  			<div class="container">
			  		<div class="row">
			  			<div class="col-lg-6 col-sm-6 col-8 header-top-left no-padding">
			  				<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-instagram"></i></a></li>
							
			  				</ul>			
			  			</div>
			  			<div class="col-lg-6 col-sm-6 col-4 header-top-right no-padding">
			  				<a href="tel:+953 012 3654 896"><span class="lnr lnr-phone-handset"></span> <span class="text">+91 9012 589 896</span></a>
			  				<a href="mailto:support@colorlib.com"><span class="lnr lnr-envelope"></span> <span class="text">nexus@university.com</span></a>			
			  			</div>
			  		</div>			  					
	  			</div>
			</div>
		    <div class="container main-menu">
		    	<div class="row align-items-center justify-content-between d-flex">
			      <div id="logo">
			        <a href="index.html"><img src="./img/logo.png" alt="" title="" /></a>
			      </div>
			      <nav id="nav-menu-container">
			        <ul class="nav-menu">
                  
      <li>
        <NavLink to="/" exact activeClassName="active">
          Home
        </NavLink>
      </li>
      <li>
        <NavLink to="/about" activeClassName="active">
          About
        </NavLink>
      </li>
      <li>
        <NavLink to="/courses" activeClassName="active">
          Case Study
        </NavLink>
      </li>
      <li>
        <NavLink to="/events" activeClassName="active">
          News & Events
        </NavLink>
      </li>
      <li>
        <NavLink to="/gallery" activeClassName="active">
          Gallery
        </NavLink>
      </li>
      <li>
        <NavLink to="/contact" activeClassName="active">
          Contact Us
        </NavLink>
      </li>
      <li>
        <NavLink to="/Login" activeClassName="active">
        Login
        </NavLink>
      </li>
    </ul>
			      </nav>		    		
		    	</div>
		    </div>
            </div>
		  </header>
 {/* section */}
          <section class="banner-area relative" id="home">
          <div class="overlay overlay-bg"></div>	
          <div class="container">
              <div class="row fullscreen d-flex align-items-center justify-content-between">
                  <div class="banner-content col-lg-12 col-md-12">
                    <br>
                    </br><br></br>
                    <br>
                    </br><br></br>
                    <br>
                    </br><br></br>
                    <br></br>
                    <br>
                    </br><br></br>
                   
                    
                      <h1 class="text-uppercase">
                      WE ARE  
                            NEXUS			
                      </h1>
                      <p class="pt-10 pb-10">
                      A vibrant community for innovators and entrepreneurs. We help you make the right connections to realise your ambitions, innovate and grow.
                      </p>
                      <a href="#" class="primary-btn text-uppercase">About Us</a><br>
                      </br><br></br><br>
                      </br><br></br><br></br><br>
                      </br><br></br>
                      <br></br><br>
                      </br><br></br><br></br><br>
                      </br><br></br>
                      <br></br>
                     
                  </div>										
              </div>
          </div>					
      </section>
      <section class="feature-area">
				<div class="container">
					<div class="row">
						<div class="col-lg-4">
							<div class="single-feature">
								<div class="title">
									<h4>Learn Online Courses</h4>
								</div>
								<div class="desc-wrap">
									<p>
										Usage of the Internet is becoming more common due to rapid advancement
										of technology.
									</p>
									<a href="#">Join Now</a>									
								</div>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="single-feature">
								<div class="title">
									<h4>No.1 of universities</h4>
								</div>
								<div class="desc-wrap">
									<p>
										For many of us, our very first experience of learning about the celestial bodies begins when we saw our first.
									</p>
									<a href="#">Join Now</a>									
								</div>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="single-feature">
								<div class="title">
									<h4>Huge Library</h4>
								</div>
								<div class="desc-wrap">
									<p>
										If you are a serious astronomy fanatic like a lot of us are, you can probably remember that one event.
									</p>
									<a href="#">Join Now</a>									
								</div>
							</div>
						</div>												
					</div>
				</div>	
			</section>        

            <section class="upcoming-event-area section-gap">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content pb-70 col-lg-8">
							<div class="title text-center">
								<h1 class="mb-10">Upcoming Events of our Institute</h1>
								<p>If you are a serious astronomy fanatic like a lot of us</p>
							</div>
						</div>
					</div>								
					<div class="row">
						<div class="active-upcoming-event-carusel">
							<div class="single-carusel row align-items-center">
								<div class="col-12 col-md-6 thumb">
									<img class="img-fluid" src="img/e1.jpg" alt=""/>
								</div>
								<div class="detials col-12 col-md-6">
								<p> Monday 12 February 2024</p>
                                <a href="#"><h4> 14:00 - 18:30
                                    Nexus</h4></a>
									<p></p>
									<a href="#"><h4>CGFI CONNECT – NET ZERO TRANSITION PLANS: CREDIBILITY AND ACTION</h4></a>
									<p>
									Join this UK CGFI Leeds Innovation Hub event to learn more about how transition plans can enable the journey to net zero and climate resilience.
                                     This event will feature representatives from the TPT, financial institutions, businesses, and academia discussing case studies and best practice in the rapidly changing policy and regulatory environment.
									</p>
								</div>
							</div>
							<div class="single-carusel row align-items-center">
								<div class="col-12 col-md-6 thumb">
									<img class="img-fluid" src="img/e2.jpg" alt=""/>
								</div>
								{/* <div class="detials col-12 col-md-6">
									<p> Monday 12 February 2024</p>
									<a href="#"><h4> 14:00 - 18:30
                                    Nexus</h4></a>
									<p>
										For most of us, the idea of astronomy is something we directly connect to “stargazing”, telescopes and seeing magnificent displays in the heavens.
									</p>
								</div> */}
							</div>	
							{/* <div class="single-carusel row align-items-center">
								<div class="col-12 col-md-6 thumb">
									<img class="img-fluid" src="img/e1.jpg" alt=""/>
								</div>
								<div class="detials col-12 col-md-6">
									<p>25th February, 2018</p>
									<a href="#"><h4>The Universe Through
									A Child S Eyes</h4></a>
									<p>
										For most of us, the idea of astronomy is something we directly connect to “stargazing”, telescopes and seeing magnificent displays in the heavens.
									</p>
								</div>
							</div>	 */}
							{/* <div class="single-carusel row align-items-center">
								<div class="col-12 col-md-6 thumb">
									<img class="img-fluid" src="img/e1.jpg" alt=""/>
								</div>
								<div class="detials col-12 col-md-6">
									<p>25th February, 2018</p>
									<a href="#"><h4>The Universe Through
									A Child S Eyes</h4></a>
									<p>
										For most of us, the idea of astronomy is something we directly connect to “stargazing”, telescopes and seeing magnificent displays in the heavens.
									</p>
								</div>
							</div> */}
							<div class="single-carusel row align-items-center">
								<div class="col-12 col-md-6 thumb">
									<img class="img-fluid" src="img/e2.jpg" alt=""/>
								</div>
								{/* <div class="detials col-12 col-md-6">
									<p>25th February, 2018</p>
									<a href="#"><h4>The Universe Through
									A Child S Eyes</h4></a>
									<p>
										For most of us, the idea of astronomy is something we directly connect to “stargazing”, telescopes and seeing magnificent displays in the heavens.
									</p>
								</div> */}
							</div>	
							{/* <div class="single-carusel row align-items-center">
								<div class="col-12 col-md-6 thumb">
									<img class="img-fluid" src="img/e1.jpg" alt=""/>
								</div>
								<div class="detials col-12 col-md-6">
									<p>25th February, 2018</p>
									<a href="#"><h4>The Universe Through
									A Child S Eyes</h4></a>
									<p>
										For most of us, the idea of astronomy is something we directly connect to “stargazing”, telescopes and seeing magnificent displays in the heavens.
									</p>
								</div>
							</div>																						 */}
						</div>
					</div>
				</div>	
			</section>  

            <section class="cta-two-area">
				<div class="container">
					<div class="row">
						<div class="col-lg-8 cta-left">
							<h1>Not Yet Satisfied with our Trend?</h1>
						</div>
						<div class="col-lg-4 cta-right">
							<a class="primary-btn wh" href="#">view our blog</a>
						</div>
					</div>
				</div>	
			</section> 

            <footer class="footer-area section-gap">
				<div class="container">
					
					<div class="footer-bottom row align-items-center justify-content-between">
						<p class="footer-text m-0 col-lg-6 col-md-4">
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved to Nexus | Made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://nexus.com" target="_blank">Nexus</a> &amp; distributed by <a href="https://themewagon.com" target="_blank">Team E</a>
</p>
						<div class="col-lg-2 col-sm-12 footer-social">
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-twitter"></i></a>
							<a href="#"><i class="fa fa-instagram"></i></a>
						
						</div>
					</div>						
				</div>
			</footer>	
      </>
    );
}
export default Home;