import React from "react";
import { Link, Outlet } from "react-router-dom";
const StudentDash = () => {
  return (
    <div>
      <header>
        <h1>Team Vellithira</h1>
      </header>
      <nav>
        <ul>
          <li>
            <Link to="Show-mark">ShowMarks</Link>
          </li>
          <li>
            <Link to="Take-exam">TakeExam</Link>
          </li>
          <li>
            <Link to="/">LogOut</Link>
          </li>
        </ul>
      </nav>
      <main>
        <Outlet />
      </main>
      <footer>
        <h2>
          All Rights Reserver@<a href="#">Team Velithira</a> 2024-25
        </h2>
      </footer>
    </div>
  );
};
export default StudentDash;
