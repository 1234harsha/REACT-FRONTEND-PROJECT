import React from "react";

export default function TakeExam()
{
    return(
        <div>
            <h3>TakeExam</h3>
        </div>
    )
}