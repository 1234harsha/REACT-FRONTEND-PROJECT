
import './App.css';
import Home from './Home/homepage';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import TakeExam from './Student/take-exam';
import ShowMarks from './Student/show-mark';
import StudentDash from './Student/student-dash';
import LoginUser from './Login/Login';
import Dashboard from './Admin/Dashboard';
;



function App() {
  return (
    <div className="App">
      <BrowserRouter>
     <Routes>
       <Route path="/" element={<LoginUser/>}>
       {/* <Route path="/Login" component={<LoginUser/>} /> */}
       </Route>
   
       <Route path="Student-dash" element={<StudentDash />}>
         <Route path="Take-exam" element={<TakeExam/>} />
         <Route path="Show-mark" element={<ShowMarks />} />
       </Route>
       </Routes>
       </BrowserRouter>
     {/* <Home/> */}
    </div>
  );
}

export default App;
